from django.apps import AppConfig

class BusinessappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'businessapp'  # Debe coincidir con el nombre de la carpeta